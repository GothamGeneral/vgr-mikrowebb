$(document).ready(function(){
	$("#contactForm").validate();
});